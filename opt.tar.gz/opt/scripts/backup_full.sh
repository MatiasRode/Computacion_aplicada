#!/bin/bash

# Funci�n de ayuda
mostrar_ayuda() {
    echo "Uso: $0 <origen> <destino>"
    echo "Realiza un backup del directorio <origen> en <destino>, en formato .tar.gz con la fecha actual."
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 1
}

# Verificar si se pidi� ayuda
if [[ "$1" == "-help" || "$1" == "--help" ]]; then
    mostrar_ayuda
fi

# Validaci�n de argumentos
if [[ $# -ne 2 ]]; then
    echo "Error: Se requieren 2 par�metros."
    mostrar_ayuda
fi

ORIGEN="$1"
DESTINO="$2"

# Verificar que el origen existe y es un directorio
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: Directorio de origen no existe: $ORIGEN"
    exit 2
fi

# Verificar que el destino existe y es un directorio
if [[ ! -d "$DESTINO" ]]; then
    echo "Error: Directorio de destino no existe: $DESTINO"
    exit 3
fi

# Verificar que el destino est� montado
if ! mountpoint -q "$DESTINO"; then
    echo "Error: El destino $DESTINO no est� montado."
    exit 5
fi

# Obtener nombre base del directorio origen (ej: log de /var/log)
NOMBRE_DIR=$(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)
ARCHIVO="$DESTINO/${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"

# Ejecutar backup
tar -czf "$ARCHIVO" "$ORIGEN"

# Verificar resultado
if [[ $? -eq 0 ]]; then
    echo "Backup creado exitosamente: $ARCHIVO"
else
    echo "Error al crear el backup."
    exit 4
fi
